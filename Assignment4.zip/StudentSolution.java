
public class StudentSolution  implements MyInterface{

	@Override
	public void insertDataFromDBFile(String objectName, int objectX, int objectY) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public String[] firstSolution(int leftTopX, int leftTopY, int rightBottomX,
			int rightBottomY) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String[] secondSolution(int leftTopX, int leftTopY,
			int rightBottomX, int rightBottomY) {
		// TODO Auto-generated method stub
		return null;
	}

}
