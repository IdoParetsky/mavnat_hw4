public class AVL<T> {
	
	public void insert(int key, T data){
		// TODO
	}

	public T search(int key){
		//TODO
		return null;
	}

	public AVLNode<T> getRoot(){
		//TODO
		return null;
	}
}

