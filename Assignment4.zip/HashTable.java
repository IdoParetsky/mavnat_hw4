import java.util.LinkedList;


public class HashTable {
	
	public void insert(ObjectWithCoordinates object){
		//TODO
	}

	public ObjectWithCoordinates search(int x, int y){
		//TODO
		return null;
	}
}

